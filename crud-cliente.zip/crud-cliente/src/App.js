import React, { Component } from 'react';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header>
          <table width={800} border={0}>
            <caption ><thead > Gerenciador de Clientes </thead></caption>
            <tr>
                <td><button onClick={"./component/CadastrarCliente.js"}>Cadastrar Cliente</button></td>
              <td><button>Buscar Cliente</button></td>
            </tr>
          </table>
        </header>
      </div>
    );
  }
}

export default App;
