import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import './index.css';
import Clientes from './components/Clientes';
import AtualizarCliente from './components/AtualizarCliente';
import CadastrarCliente from './components/CadastrarCliente';


ReactDOM.render(
    <Router>
        <div>
            <Route exact path='/' component={Clientes} />
            <Route exact path='/AtualizarCliente/:id' component={AtualizarCliente} />
            <Route exact path='/CadastrarCliente/' component={CadastrarCliente} />
        </div>
    </Router>,
    document.getElementById('root')
);
