import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import './index.css';
import Clientes from './Clientes';

export default class ClienteContainer extends React.Component{


    render(){
        return(
            <table>
                <caption><b>Desafio Desen - Clientes</b></caption>
                <tbody>
                    <tr>
                        <td><button >Cadastrar Cliente</button></td>
                        <td><Link to={'Clientes'}>Gerenciar Clientes</Link></td>
                    </tr>
                </tbody>
            </table>

        );
    }
}