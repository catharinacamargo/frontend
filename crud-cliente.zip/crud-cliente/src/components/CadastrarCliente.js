import React from 'react';
import { Link } from 'react-router-dom';
import { InputMask } from 'react-input-mask';

class CadastrarCliente extends React.Component {
    constructor(props) {
        super(props);
        this.state = {nome: '', cpf:''};
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    handleChange(event) {
        const state = this.state
        state[event.target.name] = event.target.value
        this.setState(state);
    }
    handleSubmit(event) {
        event.preventDefault();
        fetch('http://localhost:8080/api/clientes/cadastrarCliente', {
            method: 'POST',
            body: JSON.stringify({
                nome: this.state.nome,
                cpf: this.state.cpf
            }),
            headers: {
                "Content-type": "application/json; charset=UTF-8"
            }
        }).then(response => {
            alert("Cadastro realizado");

        });
    }
    render() {
        return (
            <div id="container">

                <Link to="/">Clientes</Link>
                <p/>
                <form onSubmit={this.handleSubmit}>
                    <p>
                        <label>Nome:</label>
                        <input type="text" name="nome" value={this.state.nome} onChange={this.handleChange} placeholder="Nome" />
                    </p>
                    <p>
                        <label>CPF:</label>
                        <input type="text" name="cpf" value={this.state.cpf} onChange={this.handleChange} placeholder="CPF" tag={InputMask} />
                    </p>
                    <p>
                        <input type="submit" value="Submit" />
                    </p>
                </form>
            </div>
        );
    }
}

export default CadastrarCliente;