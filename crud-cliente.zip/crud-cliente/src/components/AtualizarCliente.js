import React from 'react';
import { Link } from 'react-router-dom';

class AtualizarCliente extends React.Component {
    constructor(props) {
        super(props);
        this.state = {id: '', nome: '', cpf: ''};
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount() {
        fetch('http://localhost:8080/api/clientes/buscaPorId/' + this.props.match.params.id)
            .then(response => {
                return response.json();
            }).then(result => {
            console.log(result);
            this.setState({
                id:   result.data.id,
                nome: result.data.nome,
                cpf:  result.data.cpf
            });
        });
    }

    handleChange(event) {
        const state = this.state;
        state[event.target.name] = event.target.value;
        this.setState(state);
    }
    handleSubmit(event) {
        event.preventDefault();
        fetch('http://localhost:8080/api/clientes/atualizarCliente/' + this.state.cpf, {
            method: 'PUT',
            body: JSON.stringify({
                id:this.state.id,
                nome: this.state.nome,
                cpf: this.state.cpf
            }),
            headers: {
                "Content-type": "application/json; charset=UTF-8"
            }
        }).then(response => {


                alert("Alterado com sucesso.");


        });
    }

    render() {
        return (
            <div id="container">
                <Link to="/" >Clientes</Link>
                <p/>
                <form onSubmit={this.handleSubmit}>
                    <input type="hidden" name="id" value={this.state.id} />
                    <p>
                        <label>Nome:</label>
                        <input type="text" name="nome" value={this.state.nome} onChange={this.handleChange} placeholder="Nome" />
                    </p>
                    <p>
                        <label>CPF:</label>
                        <input type="text" name="cpf" value={this.state.cpf} onChange={this.handleChange} placeholder="CPF" />
                    </p>
                    <p>
                        <input type="submit" value="Alterar" />
                    </p>
                </form>
            </div>
        );
    }
}

export default AtualizarCliente;