import React from 'react';
import { Link } from 'react-router-dom';

class Clientes extends React.Component {
    constructor(props) {
        super(props);
        this.state = {clientes: []};
        this.headers = [
            { key: 'id', label: 'Id'},
            { key: 'nome', label: 'Nome' },
            { key: 'cpf', label: 'CPF' }
        ];

    }

    componentDidMount() {
        fetch('http://localhost:8080/api/clientes/')
            .then(response => {
                return response.json();
            }).then(result => {
            console.log(result);
            this.setState({
                clientes: result.data
            });
        });
    }

    excluirCliente(id) {
        if(window.confirm("Tem certeza que deseja excluir o registro?")) {
            return (fetch('http://localhost:8080/api/clientes/excluirCliente/' + id, {method:'delete'})
                .then(response => {
                    // if(response.status === 1) {
                        alert("Cliente excluído com sucesso.");
                        fetch('http://localhost:8080/api/clientes/')
                            .then(response => {
                                return response.json();
                            }).then(result => {
                            console.log(result);
                            this.setState({
                                clientes: result.data
                            });
                        });
                    // }
                })
        )
        }
    }

    render() {

        return (
            <div id="container">
                <p/>
                <table>
                    <caption>Gerenciador de Clientes</caption>
                    <thead>
                    <tr>
                        {
                            this.headers.map(function(h) {
                                return (
                                    <th key = {h.key}>{h.label}</th>
                                )
                            })
                        }
                        <th colSpan={2}>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.clientes.map((item, index) => {
                                return <tr key={index}>
                                    <td>{item.id}</td>
                                    <td>{item.nome}</td>
                                    <td>{item.cpf}</td>
                                    <td> <button onClick={this.excluirCliente.bind(this, item.id)}>Excluir</button></td>
                                    <td><button> <Link to={`/AtualizarCliente/${item.id}`}>Editar</Link></button></td>
                                </tr>
                            })
                        }
                        <tr>
                            <th colSpan={5}>
                                <Link to={`/CadastrarCliente`}>Cadastrar Cliente</Link>
                            </th>
                        </tr>

                    </tbody>
                </table>
            </div>
        )
    }

}

export default Clientes;